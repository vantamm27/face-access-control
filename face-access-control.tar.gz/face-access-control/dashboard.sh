#!/bin/bash

trap 'kill $(jobs -p)' SIGINT SIGTERM EXIT

xset -dpms
xset s off
xset s noblank

unclutter </dev/null &>/dev/null &

if [ -n "$1" ]; then
  #chromium-browser --window-size=1920,1080 --new-window --kiosk --incognito --noerrdialogs --disable-translate --no-first-run --fast --fast-start --disable-infobars --disable-features=TranslateUI --disk-cache-dir=/dev/null --no-first-run --no-default-browser-check --password-store=basic "$1" &
  chromium-browser --window-size=1920,1080 --new-window --kiosk --incognito --noerrdialogs --disable-translate --no-first-run --fast --fast-start --disable-infobars --disable-features=TranslateUI --no-first-run --no-default-browser-check --password-store=basic "$1" &
fi

if [ -n "$2" ]; then
  chromium-browser --window-size=1920,1080 --new-window --kiosk --incognito --noerrdialogs --disable-translate --no-first-run --fast --fast-start --disable-infobars --disable-features=TranslateUI --disk-cache-dir=/dev/null --no-first-run --no-default-browser-check --password-store=basic -–window-position=1920,0 "$2" &
fi

wait
