#!/bin/sh

#exit 0

SCRIPTPATH="$( cd "$(dirname "$0")" >/dev/null 2>&1 ; pwd -P )"
cd "${SCRIPTPATH}"

while true; do

  echo "Starting face-access-control"
  ./face-access-control

  sleep 5
done

